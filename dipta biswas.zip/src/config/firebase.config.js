export const config = {
	apiKey: "AIzaSyDNCcHVeK25hg5UNMhlPmrWk76VRfsLM78",
	authDomain: "resurantmanagement.firebaseapp.com",
	projectId: "resurantmanagement",
	storageBucket: "resurantmanagement.appspot.com",
	messagingSenderId: "442940906376",
	appId: "1:442940906376:web:cf8885e5619c266bc7383d",
	databaseURL: "https://resurantmanagement-default-rtdb.firebaseio.com/",
};
