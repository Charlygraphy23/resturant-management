import "./App.css";
import PublicRoute from "./routes/PublicRoute";

function App() {
	return (
		<div className='app'>
			<PublicRoute />
		</div>
	);
}

export default App;
